#!/bin/bash
# 启动 TUN 透明代理(劫持 Google IP 段到本机 SOCKS5)
set -e
# 解析符号链接以获取脚本真实的目录
TARGET_FILE="$0"
while [ -L "$TARGET_FILE" ]; do
  TARGET_FILE=$(readlink "$TARGET_FILE")
done
PREFIX="$(cd "$(dirname "$TARGET_FILE")" && pwd)"
PIDFILE=/tmp/hev-tun.pid
ROUTES=(142.250.0.0/15 172.217.0.0/16 216.239.32.0/19 64.233.160.0/19
        34.0.0.0/8 35.224.0.0/12 74.125.0.0/16 173.194.0.0/16
        108.177.0.0/17 209.85.128.0/17)

if [ "$(id -u)" -ne 0 ]; then
  echo "[!] up.sh must run with sudo"; exit 1
fi

# 已经在跑就跳过
if [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null; then
  echo "[=] hev-socks5-tunnel already running (pid $(cat $PIDFILE))"
else
  nohup "$PREFIX/hev-socks5-tunnel" "$PREFIX/tun.yaml" > /tmp/hev-tun.log 2>&1 &
  echo $! > "$PIDFILE"
  sleep 2
fi

TUN=$(ifconfig | grep -B1 'inet 198.18.0.1' | head -1 | awk -F: '{print $1}')
if [ -z "$TUN" ]; then
  echo "[!] TUN device not found, see /tmp/hev-tun.log"
  cat /tmp/hev-tun.log; exit 1
fi
echo "[+] TUN device = $TUN"

for cidr in "${ROUTES[@]}"; do
  route -n add -net "$cidr" -interface "$TUN" 2>&1 | head -1
done
echo "$TUN" > /tmp/agy-tun-name
echo "[+] TUN ready. Now run: agy"
