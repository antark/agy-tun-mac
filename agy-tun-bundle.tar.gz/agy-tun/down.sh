#!/bin/bash
# 停止 TUN, 清路由
PIDFILE=/tmp/hev-tun.pid
ROUTES=(142.250.0.0/15 172.217.0.0/16 216.239.32.0/19 64.233.160.0/19
        34.0.0.0/8 35.224.0.0/12 74.125.0.0/16 173.194.0.0/16
        108.177.0.0/17 209.85.128.0/17)

if [ "$(id -u)" -ne 0 ]; then
  echo "[!] down.sh must run with sudo"; exit 1
fi

for cidr in "${ROUTES[@]}"; do
  route -n delete -net "$cidr" 2>&1 | head -1
done
[ -f "$PIDFILE" ] && kill "$(cat $PIDFILE)" 2>/dev/null && rm -f "$PIDFILE"
pkill -x hev-socks5-tunnel 2>/dev/null || true
rm -f /tmp/agy-tun-name
echo "[+] TUN torn down"
